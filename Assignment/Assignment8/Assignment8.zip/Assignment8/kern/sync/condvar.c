#include <stdio.h>
#include <condvar.h>
#include <kmalloc.h>
#include <assert.h>

void     
cond_init (condvar_t *cvp) {
//================your code=====================
    cvp->count = 0;
    cvp->next = (condvar_t*) kmalloc(sizeof(condvar_t));
    cvp->next->count = 0;
    sem_init(&(cvp->sem),1);
    sem_init(&(cvp->next->sem),0);
}

// Unlock one of threads waiting on the condition variable. 
void 
cond_signal (condvar_t *cvp) {
//================your code=====================
    if(cvp->count > 0){
        cvp->next->count++;
    }
    up(&(cvp->sem));
    down(&(cvp->next->sem));
    cvp->next->count--;
}

void
cond_wait (condvar_t *cvp,semaphore_t *mutex) {
//================your code=====================
    cvp->count++;
    if(cvp->next->count > 0){
        up(&(cvp->next->sem));
    }else{
        up(mutex);
    }
    down(&(cvp->sem));
    cvp->count--;

}
