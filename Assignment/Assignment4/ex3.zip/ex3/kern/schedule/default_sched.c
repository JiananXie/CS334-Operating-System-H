#include <defs.h>
#include <list.h>
#include <proc.h>
#include <assert.h>
#include <default_sched.h>
#include <skew_heap.h>
static int

heap_comp_f(void *a, void *b)
{
     struct proc_struct *p = le2proc(a, run_pool_entry);
     struct proc_struct *q = le2proc(b, run_pool_entry);
     int32_t c = p->labschedule_good - q->labschedule_good;
     if (c > 0) return -1;
     else if (c == 0){
        if(p->pid < q->pid){
            return -1;
        }else{
            return 1;
        }
     }else return 1;
}

static void
Good_init(struct run_queue *rq) {
    list_init(&(rq->run_list));
    rq->labschedule_run_pool = NULL;
    rq->proc_num = 0;
}

static void
Good_enqueue(struct run_queue *rq, struct proc_struct *proc) {
       
    // list_add_before(&(rq->run_list), &(proc->run_link));
    // // if (proc->time_slice == 0 || proc->time_slice > rq->max_time_slice) {
    // //     proc->time_slice = rq->max_time_slice;
    // // }
    rq->labschedule_run_pool = skew_heap_insert(rq->labschedule_run_pool, &(proc->run_pool_entry),heap_comp_f);
    proc->rq = rq;
    rq->proc_num ++;
}

static void
Good_dequeue(struct run_queue *rq, struct proc_struct *proc) {
    // assert(!list_empty(&(proc->run_link)) && proc->rq == rq);
    // list_del_init(&(proc->run_link));
    rq->labschedule_run_pool = skew_heap_remove(rq->labschedule_run_pool, &(proc->run_pool_entry),heap_comp_f);
    rq->proc_num --;
}

static struct proc_struct *
Good_pick_next(struct run_queue *rq) {
    // list_entry_t *le = list_next(&(rq->run_list));
    // if (le != &(rq->run_list)) {
    //     return le2proc(le, run_link);
    // }
    if(rq->labschedule_run_pool != NULL){
        struct proc_struct *p = le2proc(rq->labschedule_run_pool, run_pool_entry);
        return p;
    }
    else{
        return NULL;
    }
    // list_entry_t *le = list_next(&(rq->run_list));

    // if (le == &rq->run_list)
    //     return NULL;
     
    // struct proc_struct *p = le2proc(le, run_link);
    // le = list_next(le);
    // while (le != &rq->run_list)
    // {
    // 	struct proc_struct *q = le2proc(le, run_link);
    //     if ((int32_t)(p->labschedule_good - q->labschedule_good) < 0 || 
    //     (int32_t)(p->labschedule_good - q->labschedule_good)== 0 && q->pid < p->pid){
    //         p = q;
    //     }
    //     le = list_next(le);
    // }
    // return p;
}

static void
Good_proc_tick(struct run_queue *rq, struct proc_struct *proc) {
    // if (proc->time_slice > 0) {
    //     proc->time_slice --;
    // }
    // if (proc->time_slice == 0) {
    //     proc->need_resched = 1;
    // }
}

struct sched_class default_sched_class = {
    .name = "Good_scheduler",
    .init = Good_init,
    .enqueue = Good_enqueue,
    .dequeue = Good_dequeue,
    .pick_next =Good_pick_next,
    .proc_tick = Good_proc_tick,
};

